AttributeCode provides a simple way to document theprovenance (i.e. origin and license) of software components thatyou use in your project. This documentation is stored in *.ABOUTfiles, side-by-side with the documented code.


