#ifndef Ta3_COMPILE_H
#define Ta3_COMPILE_H

/* These definitions must match corresponding definitions in graminit.h.
   There's code in compile.c that checks that they are the same. */
#define Py_single_input 256
#define Py_file_input 257
#define Py_eval_input 258
#define Py_func_type_input 342

#endif /* !Ta3_COMPILE_H */
