	__nest__ (
		__all__,
		'boolean', {
			__all__: {
				__inited__: false,
				__init__: function (__all__) {
					var absolute_import = __init__ (__world__.__future__).absolute_import;
					var unicode_literals = __init__ (__world__.__future__).unicode_literals;
					var print_function = __init__ (__world__.__future__).print_function;
					var BooleanAlgebra = __init__ (__world__.boolean.boolean).BooleanAlgebra;
					var Expression = __init__ (__world__.boolean.boolean).Expression;
					var Symbol = __init__ (__world__.boolean.boolean).Symbol;
					var ParseError = __init__ (__world__.boolean.boolean).ParseError;
					var PARSE_ERRORS = __init__ (__world__.boolean.boolean).PARSE_ERRORS;
					var AND = __init__ (__world__.boolean.boolean).AND;
					var NOT = __init__ (__world__.boolean.boolean).NOT;
					var OR = __init__ (__world__.boolean.boolean).OR;
					var TOKEN_TRUE = __init__ (__world__.boolean.boolean).TOKEN_TRUE;
					var TOKEN_FALSE = __init__ (__world__.boolean.boolean).TOKEN_FALSE;
					var TOKEN_SYMBOL = __init__ (__world__.boolean.boolean).TOKEN_SYMBOL;
					var TOKEN_AND = __init__ (__world__.boolean.boolean).TOKEN_AND;
					var TOKEN_OR = __init__ (__world__.boolean.boolean).TOKEN_OR;
					var TOKEN_NOT = __init__ (__world__.boolean.boolean).TOKEN_NOT;
					var TOKEN_LPAR = __init__ (__world__.boolean.boolean).TOKEN_LPAR;
					var TOKEN_RPAR = __init__ (__world__.boolean.boolean).TOKEN_RPAR;
					__pragma__ ('<use>' +
						'__future__' +
						'boolean.boolean' +
					'</use>')
					__pragma__ ('<all>')
						__all__.AND = AND;
						__all__.BooleanAlgebra = BooleanAlgebra;
						__all__.Expression = Expression;
						__all__.NOT = NOT;
						__all__.OR = OR;
						__all__.PARSE_ERRORS = PARSE_ERRORS;
						__all__.ParseError = ParseError;
						__all__.Symbol = Symbol;
						__all__.TOKEN_AND = TOKEN_AND;
						__all__.TOKEN_FALSE = TOKEN_FALSE;
						__all__.TOKEN_LPAR = TOKEN_LPAR;
						__all__.TOKEN_NOT = TOKEN_NOT;
						__all__.TOKEN_OR = TOKEN_OR;
						__all__.TOKEN_RPAR = TOKEN_RPAR;
						__all__.TOKEN_SYMBOL = TOKEN_SYMBOL;
						__all__.TOKEN_TRUE = TOKEN_TRUE;
						__all__.absolute_import = absolute_import;
						__all__.print_function = print_function;
						__all__.unicode_literals = unicode_literals;
					__pragma__ ('</all>')
				}
			}
		}
	);
