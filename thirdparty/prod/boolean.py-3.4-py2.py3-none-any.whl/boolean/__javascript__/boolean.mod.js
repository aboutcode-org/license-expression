	__nest__ (
		__all__,
		'boolean.boolean', {
			__all__: {
				__inited__: false,
				__init__: function (__all__) {
					var inspect = {};
					var itertools = {};
					var absolute_import = __init__ (__world__.__future__).absolute_import;
					var unicode_literals = __init__ (__world__.__future__).unicode_literals;
					var print_function = __init__ (__world__.__future__).print_function;
					__nest__ (inspect, '', __init__ (__world__.inspect));
					__nest__ (itertools, '', __init__ (__world__.itertools));
					var TRACE_PARSE = false;
					var TOKEN_AND = 1;
					var TOKEN_OR = 2;
					var TOKEN_NOT = 3;
					var TOKEN_LPAR = 4;
					var TOKEN_RPAR = 5;
					var TOKEN_TRUE = 6;
					var TOKEN_FALSE = 7;
					var TOKEN_SYMBOL = 8;
					var TOKEN_TYPES = dict ([[TOKEN_AND, 'AND'], [TOKEN_OR, 'OR'], [TOKEN_NOT, 'NOT'], [TOKEN_LPAR, '('], [TOKEN_RPAR, ')'], [TOKEN_TRUE, 'TRUE'], [TOKEN_FALSE, 'FALSE'], [TOKEN_SYMBOL, 'SYMBOL']]);
					var PARSE_UNKNOWN_TOKEN = 1;
					var PARSE_UNBALANCED_CLOSING_PARENS = 2;
					var PARSE_INVALID_EXPRESSION = 3;
					var PARSE_INVALID_NESTING = 4;
					var PARSE_INVALID_SYMBOL_SEQUENCE = 5;
					var PARSE_ERRORS = dict ([[PARSE_UNKNOWN_TOKEN, 'Unknown token'], [PARSE_UNBALANCED_CLOSING_PARENS, 'Unbalanced parenthesis'], [PARSE_INVALID_EXPRESSION, 'Invalid expression'], [PARSE_INVALID_NESTING, 'Invalid expression nesting such as (AND xx)'], [PARSE_INVALID_SYMBOL_SEQUENCE, 'Invalid symbols sequence such as (A B)']]);
					var ParseError = __class__ ('ParseError', [Exception], {
						get __init__ () {return __get__ (this, function (self, token_type, token_string, position, error_code) {
							if (typeof token_type == 'undefined' || (token_type != null && token_type .hasOwnProperty ("__kwargtrans__"))) {;
								var token_type = null;
							};
							if (typeof token_string == 'undefined' || (token_string != null && token_string .hasOwnProperty ("__kwargtrans__"))) {;
								var token_string = '';
							};
							if (typeof position == 'undefined' || (position != null && position .hasOwnProperty ("__kwargtrans__"))) {;
								var position = -__t__ ((1));
							};
							if (typeof error_code == 'undefined' || (error_code != null && error_code .hasOwnProperty ("__kwargtrans__"))) {;
								var error_code = 0;
							};
							self.token_type = token_type;
							self.token_string = token_string;
							self.position = position;
							self.error_code = error_code;
						});},
						get __str__ () {return __get__ (this, function (self) {
							var args = tuple ([].slice.apply (arguments).slice (1));
							var emsg = PARSE_ERRORS.py_get (self.error_code, 'Unknown parsing error');
							var tstr = '';
							if (__t__ (self.token_string)) {
								var tstr = __mod__ (' for token: "%s"', self.token_string);
							}
							var pos = '';
							if (__t__ (self.position > 0)) {
								var pos = __mod__ (' at position: %d', self.position);
							}
							return '{emsg}{tstr}{pos}'.format (__kwargtrans__ (locals ()));
						});}
					});
					var BooleanAlgebra = __class__ ('BooleanAlgebra', [object], {
						get __init__ () {return __get__ (this, function (self, TRUE_class, FALSE_class, Symbol_class, NOT_class, AND_class, OR_class) {
							if (typeof TRUE_class == 'undefined' || (TRUE_class != null && TRUE_class .hasOwnProperty ("__kwargtrans__"))) {;
								var TRUE_class = null;
							};
							if (typeof FALSE_class == 'undefined' || (FALSE_class != null && FALSE_class .hasOwnProperty ("__kwargtrans__"))) {;
								var FALSE_class = null;
							};
							if (typeof Symbol_class == 'undefined' || (Symbol_class != null && Symbol_class .hasOwnProperty ("__kwargtrans__"))) {;
								var Symbol_class = null;
							};
							if (typeof NOT_class == 'undefined' || (NOT_class != null && NOT_class .hasOwnProperty ("__kwargtrans__"))) {;
								var NOT_class = null;
							};
							if (typeof AND_class == 'undefined' || (AND_class != null && AND_class .hasOwnProperty ("__kwargtrans__"))) {;
								var AND_class = null;
							};
							if (typeof OR_class == 'undefined' || (OR_class != null && OR_class .hasOwnProperty ("__kwargtrans__"))) {;
								var OR_class = null;
							};
							self.TRUE = __t__ (TRUE_class) || _TRUE;
							self.TRUE = self.TRUE ();
							self.FALSE = __t__ (TRUE_class) || _FALSE;
							self.FALSE = self.FALSE ();
							self.TRUE.dual = self.FALSE;
							self.FALSE.dual = self.TRUE;
							self.NOT = __t__ (NOT_class) || NOT;
							self.AND = __t__ (AND_class) || AND;
							self.OR = __t__ (OR_class) || OR;
							self.Symbol = __t__ (Symbol_class) || Symbol;
							var tf_nao = dict ({'TRUE': self.TRUE, 'FALSE': self.FALSE, 'NOT': self.NOT, 'AND': self.AND, 'OR': self.OR, 'Symbol': self.Symbol});
							self._cross_refs (tf_nao);
						});},
						get _cross_refs () {return __get__ (this, function (self, objects) {
							for (var obj of objects.py_values ()) {
								for (var [py_name, value] of objects.py_items ()) {
									setattr (obj, py_name, value);
								}
							}
						});},
						get definition () {return __get__ (this, function (self) {
							return tuple ([self.TRUE, self.FALSE, self.NOT, self.AND, self.OR, self.Symbol]);
						});},
						get symbols () {return __get__ (this, function (self) {
							var args = tuple ([].slice.apply (arguments).slice (1));
							return tuple (map (self.Symbol, args));
						});},
						get parse () {return __get__ (this, function (self, expr, simplify) {
							if (typeof simplify == 'undefined' || (simplify != null && simplify .hasOwnProperty ("__kwargtrans__"))) {;
								var simplify = false;
							};
							var precedence = dict ([[self.NOT, 5], [self.AND, 10], [self.OR, 15], [TOKEN_LPAR, 20]]);
							if (__t__ (isinstance (expr, str))) {
								var tokenized = self.tokenize (expr);
							}
							else {
								var tokenized = py_iter (expr);
							}
							if (__t__ (TRACE_PARSE)) {
								var tokenized = list (tokenized);
								print ('tokens:');
								map (print, tokenized);
								var tokenized = py_iter (tokenized);
							}
							var ast = list ([null, null]);
							var is_sym = function (_t) {
								return __t__ (_t == TOKEN_SYMBOL) || isinstance (_t, Symbol);
							};
							var prev = null;
							for (var [token, tokstr, position] of tokenized) {
								if (__t__ (TRACE_PARSE)) {
									print ('\nprocessing token:', repr (token), repr (tokstr), repr (position));
								}
								if (__t__ (prev)) {
									var __left0__ = prev;
									var prev_token = __left0__ [0];
									var _ = __left0__ [1];
									var _ = __left0__ [2];
									if (__t__ (__t__ (is_sym (prev_token)) && is_sym (token))) {
										var __except0__ = ParseError (token, tokstr, position, PARSE_INVALID_SYMBOL_SEQUENCE);
										__except0__.__cause__ = null;
										throw __except0__;
									}
								}
								if (__t__ (token == TOKEN_SYMBOL)) {
									ast.append (self.Symbol (tokstr));
									if (__t__ (TRACE_PARSE)) {
										print (' ast: token == TOKEN_SYMBOL: append new symbol', repr (ast));
									}
								}
								else if (__t__ (isinstance (token, Symbol))) {
									ast.append (token);
									if (__t__ (TRACE_PARSE)) {
										print (' ast: isinstance(token, Symbol): append existing symbol', repr (ast));
									}
								}
								else if (__t__ (token == TOKEN_TRUE)) {
									ast.append (self.TRUE);
									if (__t__ (TRACE_PARSE)) {
										print ('ast4:', repr (ast));
									}
								}
								else if (__t__ (token == TOKEN_FALSE)) {
									ast.append (self.FALSE);
									if (__t__ (TRACE_PARSE)) {
										print ('ast5:', repr (ast));
									}
								}
								else if (__t__ (token == TOKEN_NOT)) {
									var ast = list ([ast, self.NOT]);
									if (__t__ (TRACE_PARSE)) {
										print ('ast6:', repr (ast));
									}
								}
								else if (__t__ (token == TOKEN_AND)) {
									var ast = self._start_operation (ast, self.AND, precedence);
									if (__t__ (TRACE_PARSE)) {
										print (' ast: token == TOKEN_AND: start_operation', repr (ast));
									}
								}
								else if (__t__ (token == TOKEN_OR)) {
									var ast = self._start_operation (ast, self.OR, precedence);
									if (__t__ (TRACE_PARSE)) {
										print (' ast: token == TOKEN_OR: start_operation', repr (ast));
									}
								}
								else if (__t__ (token == TOKEN_LPAR)) {
									if (__t__ (prev)) {
										var __left0__ = prev;
										var ptoktype = __left0__ [0];
										var _ptokstr = __left0__ [1];
										var _pposition = __left0__ [2];
										if (__t__ (!__in__ (ptoktype, tuple ([TOKEN_NOT, TOKEN_AND, TOKEN_OR, TOKEN_LPAR])))) {
											var __except0__ = ParseError (token, tokstr, position, PARSE_INVALID_NESTING);
											__except0__.__cause__ = null;
											throw __except0__;
										}
									}
									var ast = list ([ast, TOKEN_LPAR]);
								}
								else if (__t__ (token == TOKEN_RPAR)) {
									while (__t__ (true)) {
										if (__t__ (ast [0] === null)) {
											var __except0__ = ParseError (token, tokstr, position, PARSE_UNBALANCED_CLOSING_PARENS);
											__except0__.__cause__ = null;
											throw __except0__;
										}
										if (__t__ (ast [1] === TOKEN_LPAR)) {
											ast [0].append (ast [2]);
											if (__t__ (TRACE_PARSE)) {
												print ('ast9:', repr (ast));
											}
											var ast = ast [0];
											if (__t__ (TRACE_PARSE)) {
												print ('ast10:', repr (ast));
											}
											break;
										}
										if (__t__ (isinstance (ast [1], int))) {
											var __except0__ = ParseError (token, tokstr, position, PARSE_UNBALANCED_CLOSING_PARENS);
											__except0__.__cause__ = null;
											throw __except0__;
										}
										if (__t__ (!__t__ ((__t__ (inspect.isclass (ast [1])) && issubclass (ast [1], Function))))) {
											var __except0__ = ParseError (token, tokstr, position, PARSE_INVALID_NESTING);
											__except0__.__cause__ = null;
											throw __except0__;
										}
										var subex = ast [1] (...ast.__getslice__ (2, null, 1));
										ast [0].append (subex);
										if (__t__ (TRACE_PARSE)) {
											print ('ast11:', repr (ast));
										}
										var ast = ast [0];
										if (__t__ (TRACE_PARSE)) {
											print ('ast12:', repr (ast));
										}
									}
								}
								else {
									var __except0__ = ParseError (token, tokstr, position, PARSE_UNKNOWN_TOKEN);
									__except0__.__cause__ = null;
									throw __except0__;
								}
								var prev = tuple ([token, tokstr, position]);
							}
							try {
								while (__t__ (true)) {
									if (__t__ (ast [0] === null)) {
										if (__t__ (ast [1] === null)) {
											if (__t__ (len (ast) != 3)) {
												var __except0__ = ParseError (__kwargtrans__ ({error_code: PARSE_INVALID_EXPRESSION}));
												__except0__.__cause__ = null;
												throw __except0__;
											}
											var parsed = ast [2];
											if (__t__ (TRACE_PARSE)) {
												print ('parsed1:', repr (parsed));
											}
										}
										else {
											var parsed = ast [1] (...ast.__getslice__ (2, null, 1));
											if (__t__ (TRACE_PARSE)) {
												print ('parsed2:', repr (parsed));
											}
										}
										break;
									}
									else {
										var subex = ast [1] (...ast.__getslice__ (2, null, 1));
										ast [0].append (subex);
										if (__t__ (TRACE_PARSE)) {
											print ('ast13:', repr (ast));
										}
										var ast = ast [0];
										if (__t__ (TRACE_PARSE)) {
											print ('ast14:', repr (ast));
										}
									}
								}
							}
							catch (__except0__) {
								if (isinstance (__except0__, py_TypeError)) {
									var __except1__ = ParseError (__kwargtrans__ ({error_code: PARSE_INVALID_EXPRESSION}));
									__except1__.__cause__ = null;
									throw __except1__;
								}
								else {
									throw __except0__;
								}
							}
							if (__t__ (TRACE_PARSE)) {
								print ('parsed3:', repr (parsed));
							}
							if (__t__ (simplify)) {
								return parsed.simplify ();
							}
							return parsed;
						});},
						get _start_operation () {return __get__ (this, function (self, ast, operation, precedence) {
							if (__t__ (TRACE_PARSE)) {
								print ('   start_operation: ast, operation, precedence', repr (ast), repr (operation), repr (precedence));
							}
							var op_prec = precedence [operation];
							while (__t__ (true)) {
								if (__t__ (ast [1] === null)) {
									if (__t__ (TRACE_PARSE)) {
										print ('       start_op: ast[1] is None:', repr (ast));
									}
									ast [1] = operation;
									if (__t__ (TRACE_PARSE)) {
										print ('       --> start_op: ast[1] is None:', repr (ast));
									}
									return ast;
								}
								var prec = precedence [ast [1]];
								if (__t__ (prec > op_prec)) {
									if (__t__ (TRACE_PARSE)) {
										print ('       start_op: prec > op_prec:', repr (ast));
									}
									var ast = list ([ast, operation, ast.py_pop (-__t__ ((1)))]);
									if (__t__ (TRACE_PARSE)) {
										print ('       --> start_op: prec > op_prec:', repr (ast));
									}
									return ast;
								}
								if (__t__ (prec == op_prec)) {
									if (__t__ (TRACE_PARSE)) {
										print ('       start_op: prec == op_prec:', repr (ast));
									}
									return ast;
								}
								if (__t__ (!__t__ ((__t__ (inspect.isclass (ast [1])) && issubclass (ast [1], Function))))) {
									var __except0__ = ParseError (__kwargtrans__ ({error_code: PARSE_INVALID_NESTING}));
									__except0__.__cause__ = null;
									throw __except0__;
								}
								if (__t__ (ast [0] === null)) {
									if (__t__ (TRACE_PARSE)) {
										print ('       start_op: ast[0] is None:', repr (ast));
									}
									var subexp = ast [1] (...ast.__getslice__ (2, null, 1));
									var new_ast = list ([ast [0], operation, subexp]);
									if (__t__ (TRACE_PARSE)) {
										print ('       --> start_op: ast[0] is None:', repr (new_ast));
									}
									return new_ast;
								}
								else {
									if (__t__ (TRACE_PARSE)) {
										print ('       start_op: else:', repr (ast));
									}
									ast [0].append (ast [1] (...ast.__getslice__ (2, null, 1)));
									var ast = ast [0];
									if (__t__ (TRACE_PARSE)) {
										print ('       --> start_op: else:', repr (ast));
									}
								}
							}
						});},
						get tokenize () {return __get__ (this, function* (self, expr) {
							if (__t__ (!__t__ ((isinstance (expr, str))))) {
								var __except0__ = py_TypeError (__mod__ ('expr must be string but it is %s.', py_typeof (expr)));
								__except0__.__cause__ = null;
								throw __except0__;
							}
							var TOKENS = dict ({'*': TOKEN_AND, '&': TOKEN_AND, 'and': TOKEN_AND, '+': TOKEN_OR, '|': TOKEN_OR, 'or': TOKEN_OR, '~': TOKEN_NOT, '!': TOKEN_NOT, 'not': TOKEN_NOT, '(': TOKEN_LPAR, ')': TOKEN_RPAR, '[': TOKEN_LPAR, ']': TOKEN_RPAR, 'true': TOKEN_TRUE, '1': TOKEN_TRUE, 'false': TOKEN_FALSE, '0': TOKEN_FALSE, 'none': TOKEN_FALSE});
							var __left0__ = tuple ([0, len (expr)]);
							var position = __left0__ [0];
							var length = __left0__ [1];
							while (__t__ (position < length)) {
								var tok = expr [position];
								var sym = __t__ (tok.isalpha ()) || tok == '_';
								if (__t__ (sym)) {
									position++;
									while (__t__ (position < length)) {
										var char = expr [position];
										if (__t__ (__t__ (char.isalnum ()) || __in__ (char, tuple (['.', ':', '_'])))) {
											position++;
											tok += char;
										}
										else {
											break;
										}
									}
									position--;
								}
								var value = TOKENS.py_get (tok.lower ());
								if (__t__ (value)) {
									yield tuple ([value, tok, position]);
								}
								else if (__t__ (sym)) {
									yield tuple ([TOKEN_SYMBOL, tok, position]);
								}
								else if (__t__ (!__in__ (tok, tuple ([' ', '\t', '\r', '\n'])))) {
									var __except0__ = ParseError (__kwargtrans__ ({token_string: tok, position: position, error_code: PARSE_UNKNOWN_TOKEN}));
									__except0__.__cause__ = null;
									throw __except0__;
								}
								position++;
							}
						});},
						get _rdistributive () {return __get__ (this, function (self, expr, op_example) {
							if (__t__ (expr.isliteral)) {
								return expr;
							}
							var expr_class = expr.__class__;
							var args = function () {
								var __accu0__ = [];
								for (var arg of expr.args) {
									__accu0__.append (self._rdistributive (arg, op_example));
								}
								return py_iter (__accu0__);
							} ();
							var args = tuple (function () {
								var __accu0__ = [];
								for (var arg of args) {
									__accu0__.append (arg.simplify ());
								}
								return py_iter (__accu0__);
							} ());
							if (__t__ (len (args) == 1)) {
								return args [0];
							}
							var expr = expr_class (...args);
							var dualoperation = op_example.dual;
							if (__t__ (isinstance (expr, dualoperation))) {
								var expr = expr.distributive ();
							}
							return expr;
						});},
						get normalize () {return __get__ (this, function (self, expr, operation) {
							var expr = expr.literalize ();
							var expr = expr.simplify ();
							var operation_example = operation (self.TRUE, self.FALSE);
							var expr = self._rdistributive (expr, operation_example);
							var expr = expr.simplify ();
							return expr;
						});},
						get cnf () {return __get__ (this, function (self, expr) {
							return self.normalize (expr, self.AND);
						});},
						get dnf () {return __get__ (this, function (self, expr) {
							return self.normalize (expr, self.OR);
						});}
					});
					var Expression = __class__ ('Expression', [object], {
						sort_order: null,
						args: tuple (),
						isliteral: false,
						iscanonical: false,
						TRUE: null,
						FALSE: null,
						NOT: null,
						AND: null,
						OR: null,
						Symbol: null,
						get objects () {return __get__ (this, function (self) {
							return set (function () {
								var __accu0__ = [];
								for (var s of self.symbols) {
									__accu0__.append (s.obj);
								}
								return py_iter (__accu0__);
							} ());
						});},
						get get_literals () {return __get__ (this, function (self) {
							if (__t__ (self.isliteral)) {
								return list ([self]);
							}
							if (__t__ (!__t__ ((self.args)))) {
								return list ([]);
							}
							return list (itertools.chain.from_iterable (function () {
								var __accu0__ = [];
								for (var arg of self.args) {
									__accu0__.append (arg.get_literals ());
								}
								return py_iter (__accu0__);
							} ()));
						});},
						get literals () {return __get__ (this, function (self) {
							return set (self.get_literals ());
						});},
						get literalize () {return __get__ (this, function (self) {
							if (__t__ (self.isliteral)) {
								return self;
							}
							var args = tuple (function () {
								var __accu0__ = [];
								for (var arg of self.args) {
									__accu0__.append (arg.literalize ());
								}
								return py_iter (__accu0__);
							} ());
							if (__t__ (all (function () {
								var __accu0__ = [];
								for (var [i, arg] of enumerate (args)) {
									__accu0__.append (arg === self.args [i]);
								}
								return py_iter (__accu0__);
							} ()))) {
								return self;
							}
							return self.__class__ (...args);
						});},
						get get_symbols () {return __get__ (this, function (self) {
							return function () {
								var __accu0__ = [];
								for (var s of self.get_literals ()) {
									__accu0__.append ((__t__ (isinstance (s, Symbol)) ? s : s.args [0]));
								}
								return __accu0__;
							} ();
						});},
						get symbols () {return __get__ (this, function (self) {
							return set (self.get_symbols ());
						});},
						get subs () {return __get__ (this, function (self, substitutions, py_default, simplify) {
							if (typeof py_default == 'undefined' || (py_default != null && py_default .hasOwnProperty ("__kwargtrans__"))) {;
								var py_default = null;
							};
							if (typeof simplify == 'undefined' || (simplify != null && simplify .hasOwnProperty ("__kwargtrans__"))) {;
								var simplify = false;
							};
							for (var [expr, substitution] of substitutions.py_items ()) {
								if (__t__ (expr == self)) {
									return substitution;
								}
							}
							var expr = self._subs (substitutions, py_default, simplify);
							return (__t__ (expr === null) ? self : expr);
						});},
						get _subs () {return __get__ (this, function (self, substitutions, py_default, simplify) {
							var new_arguments = list ([]);
							var changed_something = false;
							if (__t__ (__t__ (self === self.TRUE) || self === self.FALSE)) {
								return self;
							}
							if (__t__ (!__t__ ((self.args)))) {
								return py_default;
							}
							for (var arg of self.args) {
								var __break1__ = false;
								for (var [expr, substitution] of substitutions.py_items ()) {
									if (__t__ (arg == expr)) {
										new_arguments.append (substitution);
										var changed_something = true;
										__break1__ = true;
										break;
									}
								}
								if (!__break1__) {
									var new_arg = arg._subs (substitutions, py_default, simplify);
									if (__t__ (new_arg === null)) {
										new_arguments.append (arg);
									}
									else {
										new_arguments.append (new_arg);
										var changed_something = true;
									}
								}
							}
							if (__t__ (!__t__ ((changed_something)))) {
								return ;
							}
							var newexpr = self.__class__ (...new_arguments);
							return (__t__ (simplify) ? newexpr.simplify () : newexpr);
						});},
						get simplify () {return __get__ (this, function (self) {
							return self;
						});},
						get __hash__ () {return __get__ (this, function (self) {
							if (__t__ (!__t__ ((self.args)))) {
								var arghash = id (self);
							}
							else {
								var arghash = hash (frozenset (map (hash, self.args)));
							}
							return hash (self.__class__.__name__) ^ arghash;
						});},
						get __eq__ () {return __get__ (this, function (self, other) {
							if (__t__ (self === other)) {
								return true;
							}
							if (__t__ (isinstance (other, self.__class__))) {
								return frozenset (self.args) == frozenset (other.args);
							}
							return NotImplemented;
						});},
						get __ne__ () {return __get__ (this, function (self, other) {
							return !__t__ ((self == other));
						});},
						get __lt__ () {return __get__ (this, function (self, other) {
							if (__t__ (__t__ (self.sort_order !== null) && other.sort_order !== null)) {
								if (__t__ (self.sort_order == other.sort_order)) {
									return NotImplemented;
								}
								return self.sort_order < other.sort_order;
							}
							return NotImplemented;
						});},
						get __gt__ () {return __get__ (this, function (self, other) {
							var lt = other.__lt__ (self);
							if (__t__ (lt === NotImplemented)) {
								return !__t__ ((self.__lt__ (other)));
							}
							return lt;
						});},
						get __and__ () {return __get__ (this, function (self, other) {
							return self.AND (self, other);
						});},
						get __mul__ () {return __get__ (this, function (self, other) {
							return self.__and__ (other);
						});},
						get __invert__ () {return __get__ (this, function (self) {
							return self.NOT (self);
						});},
						get __or__ () {return __get__ (this, function (self, other) {
							return self.OR (self, other);
						});},
						get __add__ () {return __get__ (this, function (self, other) {
							return self.__or__ (other);
						});},
						get __bool__ () {return __get__ (this, function (self) {
							var __except0__ = py_TypeError ('Cannot evaluate expression as a Python Boolean.');
							__except0__.__cause__ = null;
							throw __except0__;
						});},
						get __nonzero__ () {return __get__ (this, function (self) {
							return self.__bool__ ();
						});}
					});
					var BaseElement = __class__ ('BaseElement', [Expression], {
						sort_order: 0,
						get __init__ () {return __get__ (this, function (self) {
							__super__ (BaseElement, '__init__') (self);
							self.iscanonical = true;
							self.dual = null;
						});},
						get __lt__ () {return __get__ (this, function (self, other) {
							if (__t__ (isinstance (other, BaseElement))) {
								return self == self.FALSE;
							}
							return NotImplemented;
						});},
						get __bool__ () {return __get__ (this, function (self) {
							return null;
						});},
						get __nonzero__ () {return __get__ (this, function (self) {
							return null;
						});},
						get pretty () {return __get__ (this, function (self, indent, debug) {
							if (typeof indent == 'undefined' || (indent != null && indent .hasOwnProperty ("__kwargtrans__"))) {;
								var indent = 0;
							};
							if (typeof debug == 'undefined' || (debug != null && debug .hasOwnProperty ("__kwargtrans__"))) {;
								var debug = false;
							};
							return ' ' * indent + repr (self);
						});}
					});
					var _TRUE = __class__ ('_TRUE', [BaseElement], {
						get __init__ () {return __get__ (this, function (self) {
							__super__ (_TRUE, '__init__') (self);
						});},
						get __hash__ () {return __get__ (this, function (self) {
							return hash (true);
						});},
						get __eq__ () {return __get__ (this, function (self, other) {
							return __t__ (self === other) || __t__ (other === true) || isinstance (other, _TRUE);
						});},
						get __str__ () {return __get__ (this, function (self) {
							return '1';
						});},
						get __repr__ () {return __get__ (this, function (self) {
							return 'TRUE';
						});},
						get toString () {return __get__ (this, function (self) {
							return self.__str__ ();
						});},
						get __bool__ () {return __get__ (this, function (self) {
							return true;
						});},
						get __nonzero__ () {return __get__ (this, function (self) {
							return true;
						});}
					});
					var _FALSE = __class__ ('_FALSE', [BaseElement], {
						get __init__ () {return __get__ (this, function (self) {
							__super__ (_FALSE, '__init__') (self);
						});},
						get __hash__ () {return __get__ (this, function (self) {
							return hash (false);
						});},
						get __eq__ () {return __get__ (this, function (self, other) {
							return __t__ (self === other) || __t__ (other === false) || isinstance (other, _FALSE);
						});},
						get __str__ () {return __get__ (this, function (self) {
							return '0';
						});},
						get __repr__ () {return __get__ (this, function (self) {
							return 'FALSE';
						});},
						get toString () {return __get__ (this, function (self) {
							return self.__str__ ();
						});},
						get __bool__ () {return __get__ (this, function (self) {
							return false;
						});},
						get __nonzero__ () {return __get__ (this, function (self) {
							return false;
						});}
					});
					var Symbol = __class__ ('Symbol', [Expression], {
						sort_order: 5,
						get __init__ () {return __get__ (this, function (self, obj) {
							__super__ (Symbol, '__init__') (self);
							self.obj = obj;
							self.iscanonical = true;
							self.isliteral = true;
						});},
						get __hash__ () {return __get__ (this, function (self) {
							if (__t__ (self.obj === null)) {
								return id (self);
							}
							return hash (self.obj);
						});},
						get __eq__ () {return __get__ (this, function (self, other) {
							if (__t__ (self === other)) {
								return true;
							}
							if (__t__ (isinstance (other, self.__class__))) {
								return self.obj == other.obj;
							}
							return NotImplemented;
						});},
						get __lt__ () {return __get__ (this, function (self, other) {
							var comparator = Expression.__lt__ (self, other);
							if (__t__ (comparator !== NotImplemented)) {
								return comparator;
							}
							if (__t__ (isinstance (other, Symbol))) {
								return self.obj < other.obj;
							}
							return NotImplemented;
						});},
						get __str__ () {return __get__ (this, function (self) {
							return str (self.obj);
						});},
						get __repr__ () {return __get__ (this, function (self) {
							var obj = (__t__ (isinstance (self.obj, str)) ? __mod__ ("'%s'", self.obj) : repr (self.obj));
							return __mod__ ('%s(%s)', tuple ([self.__class__.__name__, obj]));
						});},
						get toString () {return __get__ (this, function (self) {
							return self.__str__ ();
						});},
						get pretty () {return __get__ (this, function (self, indent, debug) {
							if (typeof indent == 'undefined' || (indent != null && indent .hasOwnProperty ("__kwargtrans__"))) {;
								var indent = 0;
							};
							if (typeof debug == 'undefined' || (debug != null && debug .hasOwnProperty ("__kwargtrans__"))) {;
								var debug = false;
							};
							var debug_details = '';
							if (__t__ (debug)) {
								debug_details += __mod__ ('<isliteral=%r, iscanonical=%r>', tuple ([self.isliteral, self.iscanonical]));
							}
							var obj = (__t__ (isinstance (self.obj, str)) ? __mod__ ("'%s'", self.obj) : repr (self.obj));
							return ' ' * indent + __mod__ ('%s(%s%s)', tuple ([self.__class__.__name__, debug_details, obj]));
						});}
					});
					var Function = __class__ ('Function', [Expression], {
						get __init__ () {return __get__ (this, function (self) {
							var args = tuple ([].slice.apply (arguments).slice (1));
							__super__ (Function, '__init__') (self);
							self.operator = null;
							self.args = tuple (args);
						});},
						get __str__ () {return __get__ (this, function (self) {
							var args = self.args;
							if (__t__ (len (args) == 1)) {
								if (__t__ (self.isliteral)) {
									return __mod__ ('%s%s', tuple ([self.operator, args [0]]));
								}
								return __mod__ ('%s(%s)', tuple ([self.operator, args [0]]));
							}
							var args_str = list ([]);
							for (var arg of args) {
								if (__t__ (arg.isliteral)) {
									args_str.append (str (arg));
								}
								else {
									args_str.append (__mod__ ('(%s)', arg));
								}
							}
							return self.operator.join (args_str);
						});},
						get __repr__ () {return __get__ (this, function (self) {
							return __mod__ ('%s(%s)', tuple ([self.__class__.__name__, ', '.join (map (repr, self.args))]));
						});},
						get pretty () {return __get__ (this, function (self, indent, debug) {
							if (typeof indent == 'undefined' || (indent != null && indent .hasOwnProperty ("__kwargtrans__"))) {;
								var indent = 0;
							};
							if (typeof debug == 'undefined' || (debug != null && debug .hasOwnProperty ("__kwargtrans__"))) {;
								var debug = false;
							};
							var debug_details = '';
							if (__t__ (debug)) {
								debug_details += __mod__ ('<isliteral=%r, iscanonical=%r', tuple ([self.isliteral, self.iscanonical]));
								var identity = getattr (self, 'identity', null);
								if (__t__ (identity !== null)) {
									debug_details += __mod__ (', identity=%r', identity);
								}
								var annihilator = getattr (self, 'annihilator', null);
								if (__t__ (annihilator !== null)) {
									debug_details += __mod__ (', annihilator=%r', annihilator);
								}
								var dual = getattr (self, 'dual', null);
								if (__t__ (dual !== null)) {
									debug_details += __mod__ (', dual=%r', dual);
								}
								debug_details += '>';
							}
							var cls = self.__class__.__name__;
							var args = function () {
								var __accu0__ = [];
								for (var a of self.args) {
									__accu0__.append (a.pretty (__kwargtrans__ ({indent: indent + 2, debug: debug})));
								}
								return __accu0__;
							} ();
							var pfargs = ',\n'.join (args);
							var cur_indent = ' ' * indent;
							var new_line = (__t__ (self.isliteral) ? '' : '\n');
							return '{cur_indent}{cls}({debug_details}{new_line}{pfargs}\n{cur_indent})'.format (__kwargtrans__ (locals ()));
						});}
					});
					var NOT = __class__ ('NOT', [Function], {
						get __init__ () {return __get__ (this, function (self, arg1) {
							__super__ (NOT, '__init__') (self, arg1);
							self.isliteral = isinstance (self.args [0], Symbol);
							self.operator = '~';
						});},
						get literalize () {return __get__ (this, function (self) {
							var expr = self.demorgan ();
							if (__t__ (isinstance (expr, self.__class__))) {
								return expr;
							}
							return expr.literalize ();
						});},
						get simplify () {return __get__ (this, function (self) {
							if (__t__ (self.iscanonical)) {
								return self;
							}
							var expr = self.cancel ();
							if (__t__ (!__t__ ((isinstance (expr, self.__class__))))) {
								return expr.simplify ();
							}
							if (__t__ (__in__ (expr.args [0], tuple ([self.TRUE, self.FALSE])))) {
								return expr.args [0].dual;
							}
							var expr = self.__class__ (expr.args [0].simplify ());
							expr.iscanonical = true;
							return expr;
						});},
						get cancel () {return __get__ (this, function (self) {
							var expr = self;
							while (__t__ (true)) {
								var arg = expr.args [0];
								if (__t__ (!__t__ ((isinstance (arg, self.__class__))))) {
									return expr;
								}
								var expr = arg.args [0];
								if (__t__ (!__t__ ((isinstance (expr, self.__class__))))) {
									return expr;
								}
							}
						});},
						get demorgan () {return __get__ (this, function (self) {
							var expr = self.cancel ();
							if (__t__ (__t__ (expr.isliteral) || !__t__ ((isinstance (expr.args [0], tuple ([self.NOT, self.AND, self.OR])))))) {
								return expr;
							}
							var op = expr.args [0];
							return op.dual (...function () {
								var __accu0__ = [];
								for (var arg of op.args) {
									__accu0__.append (self.__class__ (arg).cancel ());
								}
								return py_iter (__accu0__);
							} ());
						});},
						get __lt__ () {return __get__ (this, function (self, other) {
							return self.args [0] < other;
						});},
						get pretty () {return __get__ (this, function (self, indent, debug) {
							if (typeof indent == 'undefined' || (indent != null && indent .hasOwnProperty ("__kwargtrans__"))) {;
								var indent = 1;
							};
							if (typeof debug == 'undefined' || (debug != null && debug .hasOwnProperty ("__kwargtrans__"))) {;
								var debug = false;
							};
							var debug_details = '';
							if (__t__ (debug)) {
								debug_details += __mod__ ('<isliteral=%r, iscanonical=%r>', tuple ([self.isliteral, self.iscanonical]));
							}
							if (__t__ (self.isliteral)) {
								var pretty_literal = self.args [0].pretty (__kwargtrans__ ({indent: 0, debug: debug}));
								return ' ' * indent + __mod__ ('%s(%s%s)', tuple ([self.__class__.__name__, debug_details, pretty_literal]));
							}
							else {
								return __super__ (NOT, 'pretty') (self, __kwargtrans__ ({indent: indent, debug: debug}));
							}
						});}
					});
					var DualBase = __class__ ('DualBase', [Function], {
						get __init__ () {return __get__ (this, function (self, arg1, arg2) {
							var args = tuple ([].slice.apply (arguments).slice (3));
							__super__ (DualBase, '__init__') (self, arg1, arg2, ...args);
							self.identity = null;
							self.annihilator = null;
							self.dual = null;
						});},
						get __contains__ () {return __get__ (this, function (self, expr) {
							if (__t__ (__in__ (expr, self.args))) {
								return true;
							}
							if (__t__ (isinstance (expr, self.__class__))) {
								return all (function () {
									var __accu0__ = [];
									for (var arg of expr.args) {
										__accu0__.append (__in__ (arg, self.args));
									}
									return py_iter (__accu0__);
								} ());
							}
						});},
						get simplify () {return __get__ (this, function (self) {
							if (__t__ (self.iscanonical)) {
								return self;
							}
							var args = function () {
								var __accu0__ = [];
								for (var arg of self.args) {
									__accu0__.append (arg.simplify ());
								}
								return __accu0__;
							} ();
							var expr = self.__class__ (...args);
							var expr = expr.literalize ();
							var expr = expr.flatten ();
							if (__t__ (__in__ (self.annihilator, expr.args))) {
								return self.annihilator;
							}
							var args = list ([]);
							for (var arg of expr.args) {
								if (__t__ (!__in__ (arg, args))) {
									args.append (arg);
								}
							}
							if (__t__ (len (args) == 1)) {
								return args [0];
							}
							if (__t__ (__in__ (self.identity, args))) {
								args.remove (self.identity);
								if (__t__ (len (args) == 1)) {
									return args [0];
								}
							}
							for (var arg of args) {
								if (__t__ (__in__ (self.NOT (arg), args))) {
									return self.annihilator;
								}
							}
							var i = 0;
							while (__t__ (i < len (args) - 1)) {
								var j = i + 1;
								var ai = args [i];
								if (__t__ (!__t__ ((isinstance (ai, self.dual))))) {
									i++;
									continue;
								}
								while (__t__ (j < len (args))) {
									var aj = args [j];
									if (__t__ (__t__ (!__t__ ((isinstance (aj, self.dual)))) || len (ai.args) != len (aj.args))) {
										j++;
										continue;
									}
									var negated = null;
									for (var arg of ai.args) {
										if (__t__ (__in__ (arg, aj.args))) {
											// pass;
										}
										else if (__t__ (__in__ (self.NOT (arg).cancel (), aj.args))) {
											if (__t__ (negated === null)) {
												var negated = arg;
											}
											else {
												var negated = null;
												break;
											}
										}
										else {
											var negated = null;
											break;
										}
									}
									if (__t__ (negated !== null)) {
										delete args [j];
										var aiargs = list (ai.args);
										aiargs.remove (negated);
										if (__t__ (len (aiargs) == 1)) {
											args [i] = aiargs [0];
										}
										else {
											args [i] = self.dual (...aiargs);
										}
										if (__t__ (len (args) == 1)) {
											return args [0];
										}
										else {
											return self.__class__ (...args).simplify ();
										}
									}
									j++;
								}
								i++;
							}
							var args = self.absorb (args);
							if (__t__ (len (args) == 1)) {
								return args [0];
							}
							args.py_sort ();
							var expr = self.__class__ (...args);
							expr.iscanonical = true;
							return expr;
						});},
						get flatten () {return __get__ (this, function (self) {
							var args = list (self.args);
							var i = 0;
							for (var arg of self.args) {
								if (__t__ (isinstance (arg, self.__class__))) {
									args.__setslice__ (i, i + 1, null, arg.args);
									i += len (arg.args);
								}
								else {
									i++;
								}
							}
							return self.__class__ (...args);
						});},
						get absorb () {return __get__ (this, function (self, args) {
							var args = list (args);
							if (__t__ (!__t__ ((args)))) {
								var args = list (self.args);
							}
							var i = 0;
							while (__t__ (i < len (args))) {
								var absorber = args [i];
								var j = 0;
								while (__t__ (j < len (args))) {
									if (__t__ (j == i)) {
										j++;
										continue;
									}
									var target = args [j];
									if (__t__ (!__t__ ((isinstance (target, self.dual))))) {
										j++;
										continue;
									}
									if (__t__ (__in__ (absorber, target))) {
										delete args [j];
										if (__t__ (j < i)) {
											i--;
										}
										continue;
									}
									var neg_absorber = self.NOT (absorber).cancel ();
									if (__t__ (__in__ (neg_absorber, target))) {
										var b = target.subtract (neg_absorber, __kwargtrans__ ({simplify: false}));
										if (__t__ (b === null)) {
											delete args [j];
											if (__t__ (j < i)) {
												i--;
											}
											continue;
										}
										else {
											args [j] = b;
											j++;
											continue;
										}
									}
									if (__t__ (isinstance (absorber, self.dual))) {
										var remove = null;
										for (var arg of absorber.args) {
											var narg = self.NOT (arg).cancel ();
											if (__t__ (__in__ (arg, target.args))) {
												// pass;
											}
											else if (__t__ (__in__ (narg, target.args))) {
												if (__t__ (remove === null)) {
													var remove = narg;
												}
												else {
													var remove = null;
													break;
												}
											}
											else {
												var remove = null;
												break;
											}
										}
										if (__t__ (remove !== null)) {
											args [j] = target.subtract (remove, __kwargtrans__ ({simplify: true}));
										}
									}
									j++;
								}
								i++;
							}
							return args;
						});},
						get subtract () {return __get__ (this, function (self, expr, simplify) {
							var args = self.args;
							if (__t__ (__in__ (expr, self.args))) {
								var args = list (self.args);
								args.remove (expr);
							}
							else if (__t__ (isinstance (expr, self.__class__))) {
								if (__t__ (all (function () {
									var __accu0__ = [];
									for (var arg of expr.args) {
										__accu0__.append (__in__ (arg, self.args));
									}
									return py_iter (__accu0__);
								} ()))) {
									var args = tuple (function () {
										var __accu0__ = [];
										for (var arg of self.args) {
											if (__t__ (!__in__ (arg, expr))) {
												__accu0__.append (arg);
											}
										}
										return py_iter (__accu0__);
									} ());
								}
							}
							if (__t__ (len (args) == 0)) {
								return null;
							}
							if (__t__ (len (args) == 1)) {
								return args [0];
							}
							var newexpr = self.__class__ (...args);
							if (__t__ (simplify)) {
								var newexpr = newexpr.simplify ();
							}
							return newexpr;
						});},
						get distributive () {return __get__ (this, function (self) {
							var dual = self.dual;
							var args = list (self.args);
							for (var [i, arg] of enumerate (args)) {
								if (__t__ (isinstance (arg, dual))) {
									args [i] = arg.args;
								}
								else {
									args [i] = tuple ([arg]);
								}
							}
							var prod = itertools.product (...args);
							var args = tuple (function () {
								var __accu0__ = [];
								for (var arg of prod) {
									__accu0__.append (self.__class__ (...arg).simplify ());
								}
								return py_iter (__accu0__);
							} ());
							if (__t__ (len (args) == 1)) {
								return args [0];
							}
							else {
								return dual (...args);
							}
						});},
						get __lt__ () {return __get__ (this, function (self, other) {
							var comparator = Expression.__lt__ (self, other);
							if (__t__ (comparator !== NotImplemented)) {
								return comparator;
							}
							if (__t__ (isinstance (other, self.__class__))) {
								var lenself = len (self.args);
								var lenother = len (other.args);
								for (var i = 0; i < min (lenself, lenother); i++) {
									if (__t__ (self.args [i] == other.args [i])) {
										continue;
									}
									var comparator = self.args [i] < other.args [i];
									if (__t__ (comparator !== NotImplemented)) {
										return comparator;
									}
								}
								if (__t__ (lenself != lenother)) {
									return lenself < lenother;
								}
							}
							return NotImplemented;
						});}
					});
					var AND = __class__ ('AND', [DualBase], {
						sort_order: 10,
						get __init__ () {return __get__ (this, function (self, arg1, arg2) {
							var args = tuple ([].slice.apply (arguments).slice (3));
							__super__ (AND, '__init__') (self, arg1, arg2, ...args);
							self.identity = self.TRUE;
							self.annihilator = self.FALSE;
							self.dual = self.OR;
							self.operator = '&';
						});}
					});
					var OR = __class__ ('OR', [DualBase], {
						sort_order: 25,
						get __init__ () {return __get__ (this, function (self, arg1, arg2) {
							var args = tuple ([].slice.apply (arguments).slice (3));
							__super__ (OR, '__init__') (self, arg1, arg2, ...args);
							self.identity = self.FALSE;
							self.annihilator = self.TRUE;
							self.dual = self.AND;
							self.operator = '|';
						});}
					});
					__pragma__ ('<use>' +
						'__future__' +
						'inspect' +
						'itertools' +
					'</use>')
					__pragma__ ('<all>')
						__all__.AND = AND;
						__all__.BaseElement = BaseElement;
						__all__.BooleanAlgebra = BooleanAlgebra;
						__all__.DualBase = DualBase;
						__all__.Expression = Expression;
						__all__.Function = Function;
						__all__.NOT = NOT;
						__all__.OR = OR;
						__all__.PARSE_ERRORS = PARSE_ERRORS;
						__all__.PARSE_INVALID_EXPRESSION = PARSE_INVALID_EXPRESSION;
						__all__.PARSE_INVALID_NESTING = PARSE_INVALID_NESTING;
						__all__.PARSE_INVALID_SYMBOL_SEQUENCE = PARSE_INVALID_SYMBOL_SEQUENCE;
						__all__.PARSE_UNBALANCED_CLOSING_PARENS = PARSE_UNBALANCED_CLOSING_PARENS;
						__all__.PARSE_UNKNOWN_TOKEN = PARSE_UNKNOWN_TOKEN;
						__all__.ParseError = ParseError;
						__all__.Symbol = Symbol;
						__all__.TOKEN_AND = TOKEN_AND;
						__all__.TOKEN_FALSE = TOKEN_FALSE;
						__all__.TOKEN_LPAR = TOKEN_LPAR;
						__all__.TOKEN_NOT = TOKEN_NOT;
						__all__.TOKEN_OR = TOKEN_OR;
						__all__.TOKEN_RPAR = TOKEN_RPAR;
						__all__.TOKEN_SYMBOL = TOKEN_SYMBOL;
						__all__.TOKEN_TRUE = TOKEN_TRUE;
						__all__.TOKEN_TYPES = TOKEN_TYPES;
						__all__.TRACE_PARSE = TRACE_PARSE;
						__all__._FALSE = _FALSE;
						__all__._TRUE = _TRUE;
						__all__.absolute_import = absolute_import;
						__all__.print_function = print_function;
						__all__.unicode_literals = unicode_literals;
					__pragma__ ('</all>')
				}
			}
		}
	);
